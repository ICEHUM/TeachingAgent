# 产品事实与边界

以docs/01_项目定位与交付范围.md为准。产品为AI应用开发实训教练；高职学生已有Python基础；首个任务为带来源引用的FAQ问答服务。不改成YOLO或全课程平台。

保留React/TypeScript、FastAPI、LangGraph、OpenHands SDK/Agent Server、DeepSeek和独立工作区。教师确认正式成绩，提示不直接扣分。v2记载的现有验证未在本次独立复测。

当前交付是待实施规格和无后端视觉原型，所有夹具为示例。未完成真实教学、业务联调或用户本机skill安装。
