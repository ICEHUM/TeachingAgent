# 13 现有基础、skills与待开发事项

## 13.1 现有与待开发分别记录
v2的已有基础是原文自述，本次未复测；登录、任务、教学图、持久检查点、会话、评价和导出仍是待开发。没有真实课堂成效声明。[S1，第10页]
本交付提供v3文档、Markdown执行包、设计tokens、三页HTML视觉原型、接口和测试示例、九阶段指令与安装脚本。HTML没有业务后端，数据均标示例，不能作为已完成平台。
## 13.2 Impeccable与Taste的适用方式
已核对Impeccable官方仓库pbakaus/impeccable：提供设计检查、文案、布局和发布前打磨，Codex可通过技能入口显式调用；支持项目级安装。[S3]
已核对Taste官方仓库Leonxlnx/taste-skill：当前默认design-taste-frontend为v2 experimental，主适用面是营销页、作品集与改版，不是复杂多步骤产品UI。因此可以安装，但不让其默认风格主导实训工作台；它适合单独的项目展示说明页或按需参考。[S4]
两者都是开发辅助，不进入学生容器，也不属于教学Agent运行工具。优先服从本项目PRODUCT与DESIGN；不让通用审美建议覆盖模式权限、阅读密度和任务操作。
## 13.3 安装状态与步骤
当前执行环境无法解析外网下载地址，且没有连接用户本地Codex。不能称已经安装到本包或用户电脑。tools/install_design_skills.py提供dry-run、显式安装和文件验证；实际状态保存reports。网络安装失败不影响审阅文档和原型。
官方项目级入口：npx impeccable install --providers=codex --scope=project；Taste使用skills安装器选择design-taste-frontend和codex。脚本在临时项目运行安装器，核对技能后复制；不覆盖已有同名skill，不自动启用hooks，不改业务代码。
安装前审查脚本与官方来源。第三方安装器仍会执行代码，不能以管理员身份运行。安装后检查SKILL.md与来源、记录哈希，再在真实Codex通过/skills确认；文件存在不等于所有引擎/hooks已激活。[S3,S10]
## 13.4 必须由阶段00核对
代码仓库和依赖锁；OpenHands版本所属；现有workspace接口；DeepSeek模型与工具格式；数据库/checkpoint/队列；目标机器与网络；已有AGENTS.md和skills。负责人另确认资料授权、课时人数、最后15分量规名称、迟交规则、提醒阈值与数据保留。
