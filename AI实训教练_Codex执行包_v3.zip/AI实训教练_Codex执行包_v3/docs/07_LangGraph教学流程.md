# 7 LangGraph教学流程

## 7.1 状态和节点
State只保存必要ID、任务版本、学习阶段、模式、策略、快照、证据引用、帮助级别、解释、介入事项、执行ID和状态版本。主密钥、教师答案和全库数据不放入可返回前端或长期保存的状态。
推荐节点保持v2语义：接收事件→校验与装载策略→采集证据→判断下一步→受限操作（可选）→生成指导/等待教师/阶段验收→保存业务事件并返回。不是所有分支都需要模型。
业务状态：not_started、active、awaiting_teacher、submitted、under_review、changes_requested、completed。学习阶段：understand、prepare、retrieve、cite、validate、deliver。运行状态：queued、provisioning、running、cancel_requested、succeeded、failed、cancelled、timed_out、infrastructure_error。三者分开，不混用一个status。
## 7.2 权威状态与重放
Attempt.state_version是业务权威；checkpoint按attempt_id、flow_generation关联。状态变更走乐观锁，一个Attempt同一时间最多一个教学状态变更；学生编辑仍可另存修订。
恢复前重查教师权限、事项和最新策略。LangGraph中断恢复可能重跑节点，写文件、创建容器、提交和评分都须操作去重；checkpoint不能自动回滚容器文件。[S5]
跨数据库与外部执行不能假定一个事务覆盖所有副作用。先记录operation、冻结快照、执行并记结果，重试先查询已完成记录，必要时补偿清理，不宣称端到端exactly-once。
## 7.3 预算与失败
初始建议每轮最多2次模型调用、3次工具检查、1次结构修复重试；工具30秒、外层作业120秒，均为待实测参数。达到上限返回可理解状态或转教师，不升级权限。
模型不可用、结果不合法、学生代码失败和基础设施错误分别记录。学生取消是独立请求，断开SSE不等于取消任务。未收到测试结果显示“未验证”，不是通过。
