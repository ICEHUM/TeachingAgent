# 8 OpenHands实训执行接口

## 8.1 受控工具与合同
OpenHandsExecutor是建议自研适配器名称，不是假设SDK提供同名类。沿用已有workspace与Agent Server接口；具体方法在阶段00核对当前版本，不照抄最新示例后宣称兼容。[S6,S7]
| 工具动作 | 输入 | 返回与限制 |
| --- | --- | --- |
| inspect_files | 本任务相对路径、快照 | 文件/差异；规范化及符号链接防越界 |
| run_public_checks | 任务版、快照、检查集ID | 后端映射命令；结构化检查与证据 |
| run_entrypoint | 快照、允许入口 | 受限容器日志，不能在宿主进程运行 |
| collect_log | operation_id、游标 | 归属校验、限长、转义 |
| propose_demo_patch | 演示快照、指定文件 | 返回diff，不直接写原作 |
| apply_approved_demo_patch | diff哈希、授权、版本 | 重新鉴权，严格匹配并应用一次 |
请求至少带operation_id、attempt_id、task_version_id、snapshot_id、policy_version、action、resource_profile、deadline_at。浏览器不传命令、镜像、宿主目录或任意allowed_actions；这些由服务端构造。
结果包含status、checks、evidence、artifacts、error和时间信息。stdout是学生可控制数据，正式成绩不能仅相信“全部通过”文本。
## 8.2 环境与数据隔离
Agent Server凭据只用于服务间调用，前端经过FastAPI，不直接暴露容器端口。容器只挂本任务目录，不挂Docker socket、项目主密钥、宿主目录和他人文件。
以非root、禁privileged、限制capabilities、进程/CPU/内存/磁盘/时间、只读根目录及专用可写区作为基线，按实际镜像验证。独立Docker不是执行任意恶意代码安全性的证明；课堂前检查越界、资源耗尽与网络路径，必要时采用更强沙箱。
原始提交只读保存，执行使用副本；容器回收不删除唯一持久作品。网页预览需要独立源和适当iframe sandbox，不共享管理端cookie。
## 8.3 模型代理与独立评价
学生程序使用任务级限额代理或明确标识的fixture，不得到主密钥。若默认拒绝外网，仅放行受控代理路径，或由宿主适配器代送请求；不能同时声称完全断网又让学生直连外部API。
隐藏测试和参考答案不挂进学生容器。可信评价控制器保存断言，通过独立受限runner调用学生提交，不在保存教师答案的同一进程执行学生代码，也不接受学生stdout伪造结果。
资料、代码、README和日志均是不可信输入，不能通过提示注入改变模式、工具权限或成绩。
