#!/usr/bin/env python3
"""Install two design skills at project scope. Dry-run unless --apply is given.
Requires Python3.10+, Node/npm/npx, Git, network. Official installers execute
third-party code in a temporary project; review before use. No hook activation,
no global installation, no overwrite of existing skills or application files.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,shutil,subprocess,sys,tempfile
from pathlib import Path
from datetime import datetime,timezone
NAMES=('impeccable','design-taste-frontend')
ORIGINS={'impeccable':'https://github.com/pbakaus/impeccable','design-taste-frontend':'https://github.com/Leonxlnx/taste-skill'}

def frontmatter_name(path:Path)->str|None:
 parts=path.read_text(encoding='utf-8-sig').split('---',2)
 if len(parts)!=3 or parts[0].strip():return None
 m=re.search(r'''^name:\s*['"]?([^'"\r\n]+)['"]?\s*$''',parts[1],re.M)
 return m.group(1).strip() if m else None

def hash_tree(path:Path)->str:
 h=hashlib.sha256()
 for f in sorted(path.rglob('*')):
  if f.is_symlink():raise RuntimeError(f'Symbolic link rejected: {f}')
  if f.is_file():h.update(f.relative_to(path).as_posix().encode()+b'\0'+f.read_bytes())
 return h.hexdigest()

def verify(root:Path)->list[dict]:
 results=[]
 for name in NAMES:
  folder=root/'.agents'/'skills'/name;f=folder/'SKILL.md'
  ok=f.is_file() and frontmatter_name(f)==name
  item={'name':name,'files_present':ok,'origin':ORIGINS[name],'codex_activation_verified':False}
  if ok:item['tree_sha256']=hash_tree(folder)
  results.append(item)
 return results

def run(command:list[str],cwd:Path,env:dict,timeout:int=180)->str:
 print('RUN:',' '.join(command),flush=True)
 p=subprocess.run(command,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 if p.returncode:raise RuntimeError(f'Exit {p.returncode}: {p.stdout[-5000:]}')
 return p.stdout.strip()

def main()->int:
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--project-root',type=Path,default=Path.cwd())
 modes=parser.add_mutually_exclusive_group();modes.add_argument('--apply',action='store_true');modes.add_argument('--verify-only',action='store_true')
 parser.add_argument('--impeccable-version');parser.add_argument('--skills-cli-version')
 args=parser.parse_args();root=args.project_root.expanduser().resolve()
 if not root.is_dir():parser.error('Project directory must already exist')
 if args.verify_only:
  result=verify(root);print(json.dumps(result,ensure_ascii=False,indent=2))
  return 0 if all(x['files_present'] for x in result) else 2
 print('Project:',root,'\nOnly requested skill trees will be copied. No hooks activated.')
 if not args.apply:print('DRY RUN. Use --apply after reviewing this script.');return 0
 for name in NAMES:
  if (root/'.agents'/'skills'/name).exists():raise RuntimeError(f'{name} already exists; compare manually. No overwrite.')
 npm,npx,git=(shutil.which(x) for x in ('npm','npx','git'))
 if not all((npm,npx,git)):raise RuntimeError('Node/npm/npx and Git are required')
 report={'scope':'project','started_at':datetime.now(timezone.utc).isoformat(),'status':'started','origins':ORIGINS,'installer_versions':{},'hooks_activated':False,'codex_activation_verified':False};added=[]
 try:
  with tempfile.TemporaryDirectory(prefix='design-skills-review-') as td:
   stage=Path(td);work=stage/'project';work.mkdir();(work/'.git').mkdir();home=stage/'home';home.mkdir()
   keys=('PATH','SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','TEMP','TMP','TMPDIR','HTTPS_PROXY','HTTP_PROXY','NO_PROXY','https_proxy','http_proxy','no_proxy')
   env={k:os.environ[k] for k in keys if k in os.environ}
   env.update({'HOME':str(home),'USERPROFILE':str(home),'CI':'1','DO_NOT_TRACK':'1','NPM_CONFIG_USERCONFIG':os.devnull,'NPM_CONFIG_REGISTRY':'https://registry.npmjs.org','NPM_CONFIG_CACHE':str(stage/'cache'),'NPM_CONFIG_FETCH_RETRIES':'0','NPM_CONFIG_FETCH_TIMEOUT':'10000'})
   for name,supplied in (('impeccable',args.impeccable_version),('skills',args.skills_cli_version)):
    version=supplied or json.loads(run([npm,'view',name,'version','--json'],work,env,30))
    if not isinstance(version,str) or not re.fullmatch(r'\d+\.\d+\.\d+(?:-[\w.-]+)?',version):raise RuntimeError(f'Unexpected package version: {version!r}')
    report['installer_versions'][name]=version
   run([npx,'--yes','impeccable@'+report['installer_versions']['impeccable'],'install','--providers=codex','--scope=project'],work,env)
   run([npx,'--yes','skills@'+report['installer_versions']['skills'],'add',ORIGINS['design-taste-frontend'],'--skill','design-taste-frontend','--agent','codex','--yes','--copy'],work,env)
   sources={}
   for name in NAMES:
    folder=work/'.agents'/'skills'/name
    if not (folder/'SKILL.md').is_file() or frontmatter_name(folder/'SKILL.md')!=name:raise RuntimeError(f'Installation layout changed or {name} missing; check official docs')
    hash_tree(folder);sources[name]=folder
   parent=root/'.agents'/'skills';parent.mkdir(parents=True,exist_ok=True)
   for name,source in sources.items():
    dest=parent/name
    if dest.exists():raise RuntimeError(f'Target appeared concurrently: {dest}')
    added.append(dest);shutil.copytree(source,dest)
   report['status']='skill_files_installed_activation_pending';report['skills']=verify(root)
   report['note']='Only skill trees copied. Installer hooks were left in temporary staging and not activated. Engines may need a reviewed download on first use.'
 except Exception as exc:
  for path in added:
   if path.is_dir():shutil.rmtree(path)
  report['status']='failed';report['error']=str(exc);print('FAILED:',exc,file=sys.stderr);code=1
 else:code=0;print('Files installed; verify /skills in your actual Codex. Hooks and engine activation are not verified.')
 directory=root/'reports';directory.mkdir(exist_ok=True)
 filename=directory/('skill-install-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')
 filename.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Report:',filename)
 return code
if __name__=='__main__':
 try:sys.exit(main())
 except (RuntimeError,OSError,subprocess.TimeoutExpired) as exc:print('ERROR:',exc,file=sys.stderr);sys.exit(1)
