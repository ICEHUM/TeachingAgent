"""Helper tests only: these do not test network installation or Codex activation."""
import unittest,tempfile
from pathlib import Path
from install_design_skills import frontmatter_name,verify,hash_tree,NAMES
class Tests(unittest.TestCase):
 def test_names(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)
   self.assertFalse(any(x['files_present'] for x in verify(p)))
   for n in NAMES:
    f=p/'.agents'/'skills'/n/'SKILL.md';f.parent.mkdir(parents=True);f.write_text(f'---\nname: {n}\n---\nTest',encoding='utf-8')
   self.assertTrue(all(x['files_present'] for x in verify(p)))
 def test_bad_name(self):
  with tempfile.TemporaryDirectory() as td:
   f=Path(td)/'SKILL.md';f.write_text('no metadata');self.assertIsNone(frontmatter_name(f))
 def test_hash(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td);f=p/'a';f.write_text('a');before=hash_tree(p);f.write_text('b');self.assertNotEqual(before,hash_tree(p))
 def test_symlink(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td);(p/'a').write_text('a')
   try:(p/'b').symlink_to(p/'a')
   except OSError:self.skipTest('symlinks unavailable')
   with self.assertRaises(RuntimeError):hash_tree(p)
if __name__=='__main__':unittest.main()
