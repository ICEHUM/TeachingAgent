# AI应用开发实训教练｜Codex执行包 v3

这是功能与体验规格及开发交接包，不是已完成的平台。以用户v2为主依据，保留FAQ任务、框架分工、F01—F10及A01—A10。

## 阅读与放入项目
先打开design/visual-reference.html，查看三个核心页面；所有内容为示例，无业务后端。
docs/功能设计_v3.md是主规格；各节另拆文件，减少Codex每步上下文；PRODUCT.md、DESIGN.md、AGENTS.md定义稳定边界；steps/包含00—08九阶段。
contracts/是应用层核心接口基线，不是第三方SDK代码；fixtures/是研发示例，teacher_only材料禁止挂入学生空间；reports/只证明本交付包自检。
先在项目外解压审阅，再建立开发分支合并。已有AGENTS.md、DESIGN.md等同名文件必须比较合并，不要整包覆盖实际仓库。保留.env、锁文件、数据库和学生作品。

## 第一次交给Codex
```text
读取本执行包的AGENTS.md、PRODUCT.md、DESIGN.md和steps/00_基线审计与技能安装.md。
这次只执行阶段00：审计现有仓库，核对OpenHands版本与现有接口，检查并按安装脚本安装两个设计skills，生成真实基线报告。
不要重建项目、不要升级依赖、不要改业务代码、不要覆盖已有AGENTS或hooks。
安装失败就记录真实错误，不要声称成功。完成后输出发现、验证与风险，等待我确认。
```

## Skills安装
本次环境外网解析失败，两个skills未安装到本包或你的电脑。已提供安装器与失败报告，不分发伪造的SKILL.md。
```bash
python tools/install_design_skills.py --project-root .
python tools/install_design_skills.py --project-root . --apply
python tools/install_design_skills.py --project-root . --verify-only
```
第一条只展示计划；第二条会在临时项目运行官方npm安装器并核对内容再复制，仅项目级，不自动启用hooks；已有同名skill拒绝覆盖。需要Python3.10+、Node/npm/npx、Git与网络。第三方安装器会执行代码，先审阅，不用管理员权限。
安装后在真实Codex用/skills确认可发现，文件存在不等于附加引擎与hooks已验证。Taste当前默认版不主导复杂工作台，遵循DESIGN.md。

## 开发顺序
00基线 → 01任务契约 → 02三页视觉 → 03登录发布 → 04真实运行 → 05教学指导 → 06教师评价 → 07导出演示 → 08综合验收。
每次只给Codex一个steps文件。阶段02通过不代表平台完成；最终必须接真实后端验证。
